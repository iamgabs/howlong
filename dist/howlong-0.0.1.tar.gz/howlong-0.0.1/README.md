# howlong 

Simple library to measure the execution time of a function

## How to use
~~~python
from howlong import measure_time

@measure_time
def your_function():
    pass
~~~